//
//  CollectionViewCell.swift
//  CollectionView
//
//  Created by rakeshkumar thammishetty on 12/05/19.
//  Copyright © 2019 Altair. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {


    @IBOutlet weak var imageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    
}
