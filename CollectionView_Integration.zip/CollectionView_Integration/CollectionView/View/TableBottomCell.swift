//
//  TableBottomCell.swift
//  CollectionView
//
//  Created by Narayana rao Kandregula on 13/05/19.
//  Copyright © 2019 TCS. All rights reserved.
//

import UIKit
class TableBottomCell: UITableViewCell,UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UIScrollViewDelegate {
   
    // let screenHeight = self.screenSize.height
    
    @IBOutlet weak var bottomCollectionView: UICollectionView!
    
    
 
    var imageArray2 = [String] ()
    var titlesArray = [String] ()
    override func awakeFromNib() {
        super.awakeFromNib()
        self.bottomCollectionView.delegate = self
        self.bottomCollectionView.dataSource = self
        
        imageArray2 = ["1.jpeg","2.jpeg","3.jpeg","4.jpeg","5.jpeg","6.jpeg","7.jpeg","8.jpeg","9.jpeg","10.jpeg","1.jpeg"]
        titlesArray = ["Alex","Ben","Curtan","Duke","Ester","Flemming","Ion","Jack","Kick","Lucy","Martin"]
        // Initialization code
        
        
    }
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return 10
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell: CollectionViewBottomCell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionBottonCell", for: indexPath) as? CollectionViewBottomCell
        {
            let randomNumber = Int(arc4random_uniform(UInt32(imageArray2.count)))
            
            
            cell.imageView.image = UIImage(named: imageArray2[randomNumber])
            let myString = titlesArray[indexPath.row]
            cell.titleLabel.text = myString
            cell.descLabel.text = myString
            
            return cell
        }
       
        return UICollectionViewCell()
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        let size = CGSize(width:150, height: 300)
        return size
    }
//
//    //ScrollView delegate method
//    func scrollViewDidScroll(_ scrollView: UIScrollView)
//    {
//        let pageWidth = scrollView.frame.width
//        self.currentPage = Int((scrollView.contentOffset.x + pageWidth / 2) / pageWidth)
//        self.pageContol.currentPage = self.currentPage
//    }
    
    @IBAction func onDetailButtonClick(_ sender: Any) {
        print("Detail Button Clicked")
}

}
